const fs = require('fs');
const path = require('path');
const out = path.join(__dirname, '..', 'src', 'env.js');
const config = `window.COMMANDCENTER_ENV = {
  SUPABASE_URL: ${JSON.stringify(process.env.VITE_SUPABASE_URL || '')},
  SUPABASE_ANON_KEY: ${JSON.stringify(process.env.VITE_SUPABASE_ANON_KEY || '')}
};
`;
fs.writeFileSync(out, config);
console.log('CommandCenter env.js generated');
