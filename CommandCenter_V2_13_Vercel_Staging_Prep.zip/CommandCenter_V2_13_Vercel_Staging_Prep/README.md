# CommandCenter V2.13 — Vercel Staging Prep

This package converts the V2.12 single-file prototype into a cleaner GitHub/Vercel staging structure.

## Structure

- `index.html` — app shell
- `src/styles.css` — extracted styling
- `src/app.js` — extracted CommandCenter application logic
- `src/env.js` — generated runtime config for Supabase
- `scripts/build-env.js` — Vercel build step that writes `src/env.js` from env vars

## Vercel Environment Variables

Set these in Vercel Project Settings → Environment Variables:

```
VITE_SUPABASE_URL=https://YOUR-PROJECT.supabase.co
VITE_SUPABASE_ANON_KEY=YOUR-PUBLISHABLE-ANON-KEY
```

## Deploy Steps

1. Create a new GitHub repo, for example `CommandCenter-V2.13-Staging`.
2. Upload these files to the repo root.
3. Import the repo into Vercel.
4. Add the two environment variables above.
5. Deploy.
6. Open the app. It should load in local/demo mode if Supabase is not signed in.

## Notes

- The hardcoded Supabase URL/key have been removed from the app logic.
- Cloud mode is optional; local demo mode should remain usable.
- The navigation scroll patch is preserved.
- This is staging-ready, not production SaaS security. Tenant-level RLS still needs to be tightened before real customer data.
