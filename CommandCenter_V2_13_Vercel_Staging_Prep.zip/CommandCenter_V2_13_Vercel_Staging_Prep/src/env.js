// Local fallback config. Vercel build overwrites this file from environment variables.
window.COMMANDCENTER_ENV = window.COMMANDCENTER_ENV || {
  SUPABASE_URL: "",
  SUPABASE_ANON_KEY: ""
};
